/**
 * 
 */
package com.corejava.day03.homework;

/**
 * @author   �� ��
 * @����ʱ�� Jul 23, 2013 7:22:24 PM
 * @version  v1.0
 * @since    JDK6.0
 * @��Ŀ��   CoreJava
 * @����     com.corejava.day03.homework
 * @�ļ���   Square.java
 *
 */
public class Square extends Rect {

	//����
//	private double length;
	
	//���췽��
	/*public Square() {
		super();
	}*/

	public Square(String shape,double length) {
		super(shape,length,length);
//		this.length = length;
	}

	//set\get
	/*public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}*/
	
}
