package com.corejava.day05;
//��ǽӿ�
public interface Checked {

}
