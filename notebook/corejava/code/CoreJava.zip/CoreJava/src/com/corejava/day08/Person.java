package com.corejava.day08;

public abstract class Person {

	public abstract void run();
}
