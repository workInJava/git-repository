package com.corejava.day03;

public class TestFruits {

	public static void main(String[] args) {
		Apple a1 = new Apple();
		a1.desc();
		System.out.println("//---------------");
		Apple a2 = new Apple("ƻ��","ľ��ֲ��","��ɫ");
		a2.desc();
	}
}
