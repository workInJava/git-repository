package com.corejava.day05;
/****************
 * ʵ����
 * @author 	jsd1307
 * @����ʱ�� Jul 25, 2013 4:43:44 PM
 * @version v1.0
 * @since   JDK6.0
 * @��Ŀ��   CoreJava
 * @����     com.corejava.day05
 * @�ļ���   Student.java
 *
 */
public class Student {

	private String name;
	private int age;
	
	public Student(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	public Student() {
		super();
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	@Override
	public String toString() {
		//���Լ�Ҫ��ĸ�ʽ����ƴ���ַ���
//		String str = "[����: "+name+",����: "+age+"]";
//		return str;
		//����StringBuilder��ƴ���ַ��������Ч��
		StringBuilder builder = new StringBuilder();
		builder.append("[����:").append(name)
				.append(",����:").append(age)
				.append("]");
		return builder.toString();
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Student other = (Student) obj;
		if (age != other.age)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
	
}
