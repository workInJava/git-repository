package com.corejava.day08;

public class TestScene {

	public static void main(String[] args) {
		Scene s = new Scene(1990,Season.AUTUMN);
		s.start();
	}
}
