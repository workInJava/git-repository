package com.corejava.day05;

public class TestShape {

	public static void main(String[] args) {
		Shape s1 = new Circle("Բ��",10.4);
		s1.a();
	}
}
