package com.corejava.day04;

public class TestStaticCase {

	public static void main(String[] args) {
		//���� StaticCase ����
		StaticCase sc1 = new StaticCase();
		
		System.out.println("//------------------");
		StaticCase sc2 = new StaticCase();
		System.out.println("//------------------");
		StaticCase sc3 = new StaticCase();
		
		System.out.println("//------------------");
		
		
	}
}
